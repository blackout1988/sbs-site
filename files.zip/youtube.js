/* ================================
   SBS YOUTUBE — youtube.js
   YouTube carousel + embed player
   ================================ */

const YT_API_KEY    = "AIzaSyA3arnK5Ar-A2tCH7HxEJY_TQcKnCp6sPA";
const YT_HANDLE     = "7thblocksociety";
const YT_MAX_RESULTS = 20;

let ytVideos   = [];
let ytCarouselIndex = 0;
let ytChannelId = "";

/* ── 1. Handle → Channel ID ── */
async function fetchChannelId() {
  const url = `https://www.googleapis.com/youtube/v3/channels?part=id&forHandle=${YT_HANDLE}&key=${YT_API_KEY}`;
  const res  = await fetch(url);
  const data = await res.json();
  if (data.items && data.items.length) {
    return data.items[0].id;
  }
  throw new Error("Channel not found");
}

/* ── 2. Channel ID → Videos ── */
async function fetchYouTubeVideos(channelId) {
  const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=${channelId}&maxResults=${YT_MAX_RESULTS}&order=date&type=video&key=${YT_API_KEY}`;
  const res  = await fetch(url);
  const data = await res.json();
  if (!data.items) return [];
  return data.items.map(item => ({
    id:        item.id.videoId,
    title:     item.snippet.title,
    thumb:     item.snippet.thumbnails.medium?.url || item.snippet.thumbnails.default?.url,
    published: item.snippet.publishedAt
  }));
}

/* ── 3. Render carousel ── */
function renderYouTubeCarousel() {
  const track     = document.getElementById("ytTrack");
  const modal     = document.getElementById("ytModal");
  const modalInner = document.getElementById("ytModalInner");
  const modalClose = document.getElementById("ytModalClose");
  const prevBtn   = document.getElementById("ytPrev");
  const nextBtn   = document.getElementById("ytNext");
  const section   = document.getElementById("ytSection");

  if (!track || !ytVideos.length) return;

  /* remove loader */
  const loader = document.getElementById("ytLoader");
  if (loader) loader.style.display = "none";
  if (section) section.style.display = "";

  /* build cards */
  track.innerHTML = ytVideos.map((v, i) => `
    <div class="yt-card" data-idx="${i}">
      <div class="yt-card__thumb">
        <img src="${v.thumb}" alt="${v.title}" loading="lazy" />
        <div class="yt-card__play">
          <svg viewBox="0 0 24 24" fill="white" width="28" height="28"><path d="M8 5v14l11-7z"/></svg>
        </div>
      </div>
      <div class="yt-card__title doto">${v.title}</div>
    </div>
  `).join("");

  /* card click → modal embed */
  track.querySelectorAll(".yt-card").forEach(card => {
    card.addEventListener("click", () => {
      const idx = parseInt(card.dataset.idx);
      const video = ytVideos[idx];
      modalInner.innerHTML = `
        <iframe
          src="https://www.youtube.com/embed/${video.id}?autoplay=1&rel=0"
          allow="autoplay; encrypted-media; fullscreen"
          allowfullscreen
          frameborder="0"
          style="width:100%;height:100%;border-radius:10px;">
        </iframe>`;
      modal.classList.add("is-open");
      document.body.style.overflow = "hidden";
    });
  });

  /* close modal */
  function closeModal() {
    modal.classList.remove("is-open");
    document.body.style.overflow = "";
    modalInner.innerHTML = "";
  }
  if (modalClose) modalClose.addEventListener("click", closeModal);
  document.getElementById("ytModalOverlay")?.addEventListener("click", closeModal);
  document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });

  /* carousel scroll */
  function getVisibleCount() {
    const w = window.innerWidth;
    if (w < 480) return 1;
    if (w < 768) return 2;
    if (w < 1100) return 3;
    return 4;
  }

  function scrollTo(idx) {
    const visible = getVisibleCount();
    const maxIdx  = Math.max(0, ytVideos.length - visible);
    ytCarouselIndex = Math.max(0, Math.min(idx, maxIdx));
    const cardW = track.querySelector(".yt-card")?.offsetWidth || 280;
    const gap   = 16;
    track.style.transform = `translateX(-${ytCarouselIndex * (cardW + gap)}px)`;
    if (prevBtn) prevBtn.style.opacity = ytCarouselIndex === 0 ? "0.3" : "1";
    if (nextBtn) nextBtn.style.opacity = ytCarouselIndex >= maxIdx ? "0.3" : "1";
  }

  if (prevBtn) prevBtn.addEventListener("click", () => scrollTo(ytCarouselIndex - 1));
  if (nextBtn) nextBtn.addEventListener("click", () => scrollTo(ytCarouselIndex + 1));
  window.addEventListener("resize", () => scrollTo(ytCarouselIndex));

  scrollTo(0);
}

/* ── 4. Init ── */
async function initYouTube() {
  const section = document.getElementById("ytSection");
  const loader  = document.getElementById("ytLoader");
  if (!section) return;

  try {
    ytChannelId = await fetchChannelId();
    ytVideos    = await fetchYouTubeVideos(ytChannelId);
    renderYouTubeCarousel();
  } catch(err) {
    console.warn("[SBS] YouTube fetch failed:", err);
    if (loader) loader.textContent = "VIDEOS UNAVAILABLE";
  }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initYouTube);
} else {
  initYouTube();
}
